# Soffiolieve HD-2D

Demo browser e laboratorio lotte singole. Progetto amatoriale non ufficiale.

## Pubblicazione
GitHub Pages: branch `main`, cartella `/ (root)`. Nessuna build o server Node necessario. Il sito usa percorsi relativi compatibili con una pagina di progetto.

Comandi: WASD/frecce, E per interagire; controlli touch sugli schermi piccoli. Attivare l’audio dal pulsante dedicato.

Copertura e limiti: ANIMAZIONI.txt e AUDIO.txt. Il file ROM originale non è incluso.
